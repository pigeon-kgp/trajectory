import json
import math
import cv2
from pprint import pprint
import numpy as np

data={}
with open('out.json') as data_file:    
    data = json.load(data_file)

end=[4368.08, 8160.37]
print type(data)
for each in data:
	# start=[4329.13,8385.88]
	start=data[each]['from']
	#end=[3938.83, 7782.57]
	nowhere=start

	prev=-2
	ihere=0
	pts=[]
	pts_global=[]
	iees=[]
	finalpoints=[]
	img=np.zeros((1100, 1100, 3), np.uint8)
	while(1):
		stat="ok"
		if nowhere==end: break
		prevlength=np.inf
		flag=False
		count=0; countfound=0
		for i in data:
			count+=1
			#print count
			if data[i]['from']==nowhere:
				if data[i]['to']==end: flag=True; break
				if data[i]['to'] in pts: continue
				countfound+=1
				length=math.fabs(data[i]["distance"])*data[i]['traffic']+math.fabs(data[i]['to'][0]-end[0])+math.fabs(data[i]['to'][1]-end[1])
				if length<prevlength:
					print "Found a way!"
					prevlength=length
					nowfrom=data[i]['from']
					now=data[i]['to']
					ihere=i
					# iees.append(i)
					
		if count<=1 or countfound<=1: stat="failed";prev-=1
		cv2.line(img,(int(nowfrom[1])-7800,int(nowfrom[0])-4000),(int(now[1])-7800,int(now[0])-4000),(255,0,0))
		print "points: "+str(((int(nowfrom[1])-7800,int(nowfrom[0])-4000),(int(now[1])-7800,int(now[0])-4000),(255,0,0)))
		print "actual point: "+str(now)
		pts.append(now)
		pts_global.append([nowfrom,now])
		iees.append(ihere)
		nowhere=now
		print pts
		print countfound
		if flag==True: break
		if count<=1 or countfound<=1:
			try:
				nowhere=data[iees[prev]]['from']
				# pts_global=pts_global[:prev]
				print ("prev: ",prev)
				# exit()
			except:
				print "Failed"
				prev=-2
			print "nowhere: "+str(nowhere)
			print "Failed"
			prev-=1

	# print ("The point is: ",int(end[1])-7800,int(end[0])-4000)

	# pts_global.append(end)
	# pts_global.append([(1100-1)/2,(1100-1)/2])
	print (len(data))
	# print ("Final path: ",pts_global)
	# for i in xrange(1,len(pts_global)):
		# pass
		# cv2.line(img,(int(pts_global[i-1][1])-7800,int(pts_global[i-1][0])-4000),(int(pts_global[i][1])-7800,int(pts_global[i][0])-4000),(255,255,255))
		# print ("pts here from: ",int(pts_global[i-1][1])-7800,int(pts_global[i-1][0])-4000,\
			   # " to: ",int(pts_global[i][1])-7800,int(pts_global[i][0])-4000)
		# img[int(pts_global[i][0])-4000,int(pts_global[i][1])-7800]=(255,255,255)
	# print ("end: ",end)
	# print ("pts_global", pts_global)
	# cv2.line(img,(0,0),((1100-1)/2,(1100-1)/2),(0,0,255))
	img[int(end[0])-4000,int(end[1])-7800]=(0,255,0)
	img[int(start[0])-4000,int(start[1])-7800]=(255,255,255)
	# img[((1100-1)/2,(1100-1)/2)]=(255,255,255)
	oh_my_pt=None
	for pt in pts_global:
		if pt[0]==start: oh_my_pt=pt[1]


	cv2.imshow("path",img)
	cv2.waitKey(0)
	if flag==True:
		print "Reached"
	else: continue

	f=open("tables/"+str(start),"w")
	f.write(str(end)+": "+str(oh_my_pt))
	f.close()


'''
import random
now=start

ihere=0
iees=[]
while(1):
	randomi=[]
	for a in xrange(500):
		a.append(random.randrange(0,len(data)))
	if now==end: break
	prevlength=np.inf
	flag=False
	count=0; countfound=0
	img=np.zeros((1000, 1000, 3), np.uint8)
	for i in data:
		count+=1
		#print count
		if data[i]['from']==now:
			if data[i]['to']==end: flag=True; break
			if data[i]['to'] in iees: continue
			countfound+=1
			length=math.fabs(data[i]["distance"])*data[i]['traffic']+math.fabs(data[i]['to'][0]-end[0])+math.fabs(data[i]['to'][1]-end[1])
			if length<prevlength:
				print "Found a way!"
				prevlength=length
				nowfrom=data[i]['from']
				now=data[i]['to']
				ihere=i
				#iees.append(i)
				

	cv2.line(img,(int(nowfrom[1])-4000,int(nowfrom[0])-7000),(int(now[1])-4000,int(now[0])-7000),(255,255,255))
	print "points: "+str(((int(nowfrom[1])-4000,int(nowfrom[0])-7000),(int(now[1])-4000,int(now[0])-7000),(255,255,255)))
	iees.append(now)
	print iees
	print countfound
	if flag==True: break
	if count<=1 or countfound<=1: print "Failed"; break
	'''